<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.flipkart.entity.ProfileEntity" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>All Users</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f2f5;
        display: flex;
        justify-content: center;
        padding-top: 50px;
    }

    .container {
        background-color: #ffffff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        width: 500px;
    }

    h2 {
        text-align: center;
        color: #0073e6;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        padding: 10px;
        text-align: left;
        border: 1px solid #ccc;
    }

    th {
        background-color: #0073e6;
        color: white;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .no-users {
        text-align: center;
        color: #888;
        font-style: italic;
    }
</style>
</head>
<body>
    <div class="container">
        <h2>All Users</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Mobile</th>
            </tr>

        <%
            // Get users list from request attribute
            List<ProfileEntity> users = (List<ProfileEntity>) request.getAttribute("users");

            if (users != null && !users.isEmpty()) {
                for (ProfileEntity u : users) {
        %>
            <tr>
                <td><%= u.getId() %></td>
                <td><%= u.getEmail() %></td>
                <td><%= u.getMobile() %></td>
                 <td>
        <a href="editProfile?id=<%= u.getId() %>">Edit</a>
        <a href="deleteProfile?id=<%= u.getId() %>"
       onclick="return confirm('Are you sure?')">Delete</a>
    </td>
            </tr>
        <%
                }
            } else {
        %>
            <tr>
                <td colspan="3" class="no-users">No users found</td>
            </tr>
        <%
            }
        %>
        </table>
    </div>
  
</body>
</html>
